import React from 'react'
import {ComingSoon} from './index'
function Shop() {
  return (
    <div className="flex justify-center items-center text-center h-screen bg-gray-950 text-amber-400">
      <ComingSoon />
    </div>
  )
}

export default Shop
