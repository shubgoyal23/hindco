import React from 'react'

function Contact() {
  return (
    <div className="flex justify-center items-center text-center h-screen bg-gray-950 text-amber-400">
      <a className='text-2xl' href="mailto:goyalshubham@outlook.in">goyalshubham@outlook.in</a>
      
    </div>
  )
}

export default Contact
