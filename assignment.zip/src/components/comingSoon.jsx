import React from 'react';

const ComingSoon = () => {
  return (
    <div>
      <h1 className="mb-6 text-2xl">Website Under Construction</h1>
      <p className="text-xl">We're currently working on this website. Please check back later!</p>
    </div>
  );
};

export default ComingSoon;
